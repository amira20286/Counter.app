let counters = JSON.parse(localStorage.getItem("counters")) || [
    { name: "استغفار", value: 0 },
    { name: "الصلاة على النبي ﷺ", value: 0 },
    { name: "لا حول ولا قوة إلا بالله", value: 0 }
];

function renderCounters() {
    const container = document.getElementById("counterContainer");
    container.innerHTML = "";
    counters.forEach((counter, index) => {
        const counterElement = document.createElement("div");
        counterElement.className = "counter";
        counterElement.innerHTML = `
            <input type="text" value="${counter.name}" oninput="updateName(${index}, this.value)" placeholder="اسم المسبحة">
            <div class="button-group">
                <button onclick="decrease(${index})">➖</button>
                <span id="counter-value-${index}">${counter.value}</span>
                <button onclick="increase(${index})">➕</button>
            </div>
            <div class="button-group">
                <button onclick="resetCounter(${index})">🔄</button>
                <button onclick="setCounter(${index})">⚙</button>
                <button onclick="deleteCounter(${index})">🗑</button>
            </div>
        `;
        container.appendChild(counterElement);
    });
    saveCounters();
}

function addCounter() {
    counters.push({ name: "مسبحة جديدة", value: 0 });
    renderCounters();
}

function increase(index) {
    counters[index].value++;
    renderCounters();
}

function decrease(index) {
    if (counters[index].value > 0) {
        counters[index].value--;
        renderCounters();
    }
}

function resetCounter(index) {
    counters[index].value = 0;
    renderCounters();
}

function setCounter(index) {
    let newValue = prompt("أدخل القيمة الجديدة للمسبحة:", counters[index].value);
    if (newValue !== null && !isNaN(newValue)) {
        counters[index].value = parseInt(newValue);
        renderCounters();
    }
}

function updateName(index, newName) {
    counters[index].name = newName;
    saveCounters();
}

function deleteCounter(index) {
    counters.splice(index, 1);
    renderCounters();
}

function saveCounters() {
    localStorage.setItem("counters", JSON.stringify(counters));
}

renderCounters();
    renderCounters();
}

function updateName(index, newName) {
    counters[index].name = newName;
    saveCounters();
}

function deleteCounter(index) {
    counters.splice(index, 1);
    renderCounters();
}

function saveCounters() {
    localStorage.setItem("counters", JSON.stringify(counters));
}

renderCounters();
