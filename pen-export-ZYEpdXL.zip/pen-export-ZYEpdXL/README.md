# عداد تسبيح

A Pen created on CodePen.

Original URL: [https://codepen.io/Amira_86/pen/ZYEpdXL](https://codepen.io/Amira_86/pen/ZYEpdXL).

